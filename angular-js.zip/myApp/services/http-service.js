app.service("httpService", function() {

    var countryData = [{id:1, name: 'INDIA'}, {id:2, name: 'CANADA'}, {id:3, name: 'USA'}];

    this.getData = function () {
        return countryData;
    }

    this.postData = function (countryValue) {
        var date = new Date();
        countryData.push({
            id: date.getTime(),
            name: countryValue
        });
    }

    this.updateData = function (countryValue, index) {
        countryData[index].name = countryValue;
    }
});