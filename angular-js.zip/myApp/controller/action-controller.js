app.controller('actionController', function($scope, httpService) {
    

    $scope.countryData = httpService.getData();
    $scope.addMaterials = false;
    $scope.editMaterials = false;
    $scope.editIndex = null;

    $scope.modalAction = function(actionType, index) {
        switch(actionType){
            case 'add':
                $scope.addMaterials = true;
                $scope.editMaterials = false;
            break;
            case 'edit':
                $scope.countryValue = $scope.countryData[index].name;
                $scope.editIndex = index;
                $scope.addMaterials = false;
                $scope.editMaterials = true;
            break;
        }
    }

    $scope.addAction = function() {
        httpService.postData($scope.countryValue);
        $scope.countryValue = null;
    }

    $scope.editAction = function() {
        httpService.updateData($scope.countryValue, $scope.editIndex);
        $scope.editIndex = null;
        $scope.countryValue = null;
    }
 
});